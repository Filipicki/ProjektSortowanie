#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <time.h>

using namespace std;

const int n = 40; // Liczebno�� zbioru.
const int iloscciagow = 20; // ilosc ciagow
int d[n];

// Sortowanie szybkie

void Sortszybki(int lewy, int prawy)
{
    int i,j,piwot;

    i = (lewy + prawy) / 2;
    piwot = d[i]; d[i] = d[prawy];
    for(j = i = lewy; i < prawy; i++)
        if(d[i] < piwot)
        {


            swap(d[i], d[j]);
            j++;
        }
    d[prawy] = d[j]; d[j] = piwot;
    if(lewy < j - 1)  Sortszybki(lewy, j - 1);
    if(j + 1 < prawy) Sortszybki(j + 1, prawy);
}
// sortowanie gnoma
void Gnom (int* lista, int n) {
    int pos = 0;
    while (pos < n) {
        if (pos == 0 || lista[pos] >= lista[pos - 1]) {
            pos++;
        } else {
            swap(lista[pos], lista[pos - 1]);
            pos = pos - 1;
        }
    }
}
// Program g��wny
int main()
{
    int i; int iloscciagowszybkie = 25; int iloscciagowdgnom = 25;
    int ciag1[n];
    int ciag[n];
    FILE *glownyplik;
    FILE *Sortowanie_szybkie;
    FILE *Sortowanie_gnom;

    glownyplik = fopen("dane_wejsciowe.txt","a+");
    srand((unsigned)time(NULL));

    for(int j = 0; j < iloscciagow; j++) {
        for (i = 0; i < n; i++) {
            ciag1[i] = rand() % 100;
            fprintf(glownyplik, "%d ", ciag1[i]);
        }
        fprintf(glownyplik, "%s", "\n");
    }

// Sortowanie
    fseek(glownyplik,0,0);
    Sortowanie_szybkie = fopen("Sortowanie_szybkie.txt","a");
    Sortowanie_gnom = fopen("Sortowanie_gnom.txt","a");
    for(int j = 0; j < iloscciagowszybkie; j++) {
        for (i = 0; i < n; i++) {
            fscanf(Sortowanie_szybkie, "%d", &d[i]);
        }
        Sortszybki(0, n - 1);
        for (i = 0; i < n; i++) {
            fprintf(Sortowanie_szybkie, "%d ", d[i]);
        }
        fprintf(Sortowanie_szybkie, "%s", "\n");
    }
    for(int j = 0; j < iloscciagowdgnom; j++) {
        for (i = 0; i < n; i++) {
            fscanf(glownyplik, "%d", &ciag[i]);
        }
        Gnom(ciag, n);
        for (i = 0; i < n; i++) {
            fprintf(Sortowanie_gnom, "%d ", ciag[i]);
        }
        fprintf(Sortowanie_gnom, "%s", "\n");
    }

    fclose(glownyplik);
    fclose(Sortowanie_szybkie);
    fclose(Sortowanie_gnom);
    return 0;
}
